function Testimonial() {
  return (
    <div className="TestimonialContainer" id="TestimonialContainer">
      This is testimonial
    </div>
  );
}

export default Testimonial;
