function Designation() {
  return (
    <div className="DesignationContainer" id="DesignationContainer">
      This is designation container
    </div>
  );
}

export default Designation;
