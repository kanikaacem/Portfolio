function Contact() {
  return (
    <div className="ContactContainer" id="ContactContainer">
      This is Contact us container
    </div>
  );
}

export default Contact;
